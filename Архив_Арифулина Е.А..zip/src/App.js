import React from "react";
import "./App.scss";
import MainBox from "./components/MainBox";

function App() {
  return (
    <div className="app">
      <MainBox />
    </div>
  );
}

export default App;
